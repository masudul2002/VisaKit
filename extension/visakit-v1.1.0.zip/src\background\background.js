(function(){"use strict";function i(){console.log("VisaKit Background Service Worker Initialized")}i()})();
