(function(){"use strict";const I={scan:()=>{const t=[];return document.querySelectorAll("input, select, textarea").forEach(e=>{if(e.tagName==="INPUT"){const o=(e.type||"text").toLowerCase();if(["hidden","submit","button","image","reset","file"].includes(o))return}const i=window.getComputedStyle(e);i.display==="none"||i.visibility==="hidden"||t.push(e)}),t}},w={surname:["surname","lastname","familyname","last_name","family_name","lName"],givenName:["givenname","firstname","first_name","fname","name"],gender:["gender","sex"],dob:["dob","dateofbirth","birthdate","birth_date","date_of_birth"],birthPlace:["birthplace","placeofbirth","place_of_birth"],nationality:["nationality","citizen","citizenship"],passportNumber:["passportnumber","passportno","passport_number","passport_no","passno"],passportIssueDate:["passportissuedate","issue_date","issuedate","dateofissue"],passportExpiryDate:["passportexpirydate","expiry_date","expirydate","dateofexpiry","expirationdate"],passportIssuePlace:["passportissueplace","placeofissue","issueplace","issue_place"],religion:["religion","faith"],maritalStatus:["maritalstatus","marital_status","marriage"],occupation:["occupation","profession","job","work"],email:["email","emailaddress","email_address","mail"],phone:["phone","phonenumber","phone_number","mobile","cell","tel"],address:["address","streetaddress","street","addressline1"],city:["city","town","district"],country:["country","nation"],postalCode:["postalcode","zipcode","zip","postal_code","pin","pincode"],visaType:["visatype","type_of_visa","visa_type","prev_visa_type","previous_visa_type","visa_type_selected"]},k={normalize:t=>t.toLowerCase().trim().replace(/[\s\-_]+/g,"").replace(/[^a-z0-9]/g,""),normalizeLabel:t=>t.toLowerCase().trim().replace(/\s+/g," ")},A={match:t=>{if(!t)return null;const a=k.normalize(t);for(const[e,i]of Object.entries(w))if(i.some(r=>k.normalize(r)===a||a.includes(k.normalize(r))))return e;return null}},_={match:t=>{if(!t)return null;const a=k.normalize(t);for(const[e,i]of Object.entries(w))for(const r of i){const o=k.normalize(r);if(a===o||a.includes(o))return e}return null}},z={match:t=>_.match(t)},C=new WeakMap,E={mapField:t=>{if(C.has(t))return C.get(t)||null;const a=E.resolveField(t);return C.set(t,a),a},resolveField:t=>{const a=t.getAttribute("name");let e=A.match(a);if(e)return e;const i=t.getAttribute("id");if(e=A.match(i),e)return e;const r=t.getAttribute("autocomplete");if(e=A.match(r),e)return e;const o=E.getLabelText(t);if(e=_.match(o),e)return e;const s=t.getAttribute("placeholder");if(e=z.match(s),e)return e;const p=t.getAttribute("aria-label");return e=_.match(p),e||null},getLabelText:t=>{if("labels"in t&&t.labels&&t.labels.length>0)return t.labels[0].textContent;const a=t.getAttribute("id");if(a){const r=document.querySelector(`label[for="${a}"]`);if(r)return r.textContent}const e=t.closest("label");if(e)return e.textContent;const i=t.closest("td");if(i){const r=i.previousElementSibling;if(r&&r.textContent)return r.textContent}return null}},L={hili:"BY ROAD HILI",benapole:"BY ROAD PETRAPOLE",gede:"BY ROAD GEDE",haridaspur:"BY ROAD HARIDASPUR",jaigaon:"BY ROAD JAIGAON",dawki:"BY ROAD DAWKI"},F={religion:{label:"Religion",aliases:["religion","faith"],type:"select",resolver:(t,a)=>{const e=t.toUpperCase().trim(),i=a.find(r=>r.value.toUpperCase().trim()===e||r.text.toUpperCase().trim()===e);return i?i.value:null}},education:{label:"Education",aliases:["education","qualification"],type:"select",resolver:(t,a)=>{const e=t.toUpperCase().trim(),i=a.find(r=>r.value.toUpperCase().trim()===e||r.text.toUpperCase().trim()===e);return i?i.value:null}},nationality:{label:"Nationality",aliases:["nationality","citizenship"],type:"select",resolver:(t,a)=>{const e=t.toLowerCase().trim();if(e==="bangladesh"||e==="bgd"||e==="bangladeshi"){const r=a.find(o=>o.value==="BGD"||o.text.includes("BANGLADESH"));if(r)return r.value}const i=a.find(r=>r.value.toLowerCase()===e||r.text.toLowerCase().includes(e));return i?i.value:null}},maritalStatus:{label:"Marital Status",aliases:["maritalstatus","marital_status"],type:"select",resolver:(t,a)=>{const e=t.toUpperCase().trim(),i=a.find(r=>r.value.toUpperCase().trim()===e||r.text.toUpperCase().trim()===e);return i?i.value:null}},occupation:{label:"Occupation",aliases:["occupation","profession"],type:"select",resolver:(t,a)=>{const e=t.toUpperCase().trim(),i=a.find(r=>r.value.toUpperCase().trim()===e||r.text.toUpperCase().trim()===e);return i?i.value:null}},arrivalPort:{label:"Arrival Port",aliases:["arrivalport","portofentry","entry_port"],type:"select",resolver:(t,a)=>{const e=t.toLowerCase().trim(),r=(L[e]||t).toLowerCase().trim(),o=a.find(s=>s.value.toLowerCase().trim()===r||s.text.toLowerCase().trim().includes(r));return o?o.value:null}},exitPort:{label:"Exit Port",aliases:["exitport","portofexit","exit_port"],type:"select",resolver:(t,a)=>{const e=t.toLowerCase().trim(),r=(L[e]||t).toLowerCase().trim(),o=a.find(s=>s.value.toLowerCase().trim()===r||s.text.toLowerCase().trim().includes(r));return o?o.value:null}},visaType:{label:"Visa Type",aliases:["visatype","type_of_visa","visa_type","previous_visa_type","prev_visa_type"],type:"select",resolver:(t,a)=>{const e=t.toUpperCase().trim(),i=a.find(o=>o.value.toUpperCase().trim()===e||o.text.toUpperCase().trim()===e);if(i)return i.value;const r=a.find(o=>o.text.toUpperCase().trim().includes(e)||e.includes(o.text.toUpperCase().trim()));return r?r.value:null}}},M={resolve:(t,a,e)=>{var o;const i=e[a];if(i==null)return null;const r=t.tagName;if(r==="SELECT"){const s=t,p=String(i),d=F[a];if(d&&d.resolver){const c=Array.from(s.options),f=d.resolver(p,c);if(f!==null)return f}const n=p.toLowerCase().trim();for(let c=0;c<s.options.length;c++){const f=s.options[c];if(f.value.toLowerCase().trim()===n||f.text.toLowerCase().trim()===n)return f.value}return((o=s.options[0])==null?void 0:o.value)||null}if(r==="INPUT"){const s=t;if(s.type==="radio"){const n=s.value.toLowerCase().trim(),c=String(i).toLowerCase().trim();return n===c||c.startsWith(n)}if(s.type==="checkbox")return!!i;const p=s.getAttribute("placeholder")||"",d=String(i);if(d.includes("-")&&(p.includes("DD/MM/YYYY")||p.includes("dd/mm/yyyy"))){const n=d.split("-");if(n.length===3)return`${n[2]}/${n[1]}/${n[0]}`}}return String(i)}},D={resolveValue:(t,a,e)=>M.resolve(t,a,e)},h={info:t=>{console.log(`[VisaKit Info]: ${t}`)},warn:t=>{console.warn(`[VisaKit Warning]: ${t}`)},error:(t,a)=>{console.error(`[VisaKit Error]: ${t}`,a)}},x={fill:(t,a)=>{try{if(t.tagName==="INPUT"&&t.type==="radio"){const i=t;return!!a&&!i.checked?(i.checked=!0,x.triggerEvents(i,["change","click"]),!0):!1}if(t.tagName==="INPUT"&&t.type==="checkbox"){const i=t,r=!!a;return i.checked!==r?(i.checked=r,x.triggerEvents(i,["change","click"]),!0):!1}const e=String(a);return t.value!==e?(t.value=e,x.triggerEvents(t,["input","change","blur"]),!0):!1}catch(e){return h.error(`Failed to set value on element ${t.tagName}`,e),!1}},triggerEvents:(t,a)=>{a.forEach(e=>{const i=new Event(e,{bubbles:!0,cancelable:!0});t.dispatchEvent(i)})}},P={runAutofill:async t=>{const a=performance.now();let e=0,i=0,r=0,o=0;try{h.info("Autofill engine started scanning DOM.");const p=I.scan();h.info(`Found ${p.length} potential form fields.`);for(const d of p)try{const n=E.mapField(d);if(!n){i++;continue}o++;const c=D.resolveValue(d,n,t);if(c==null){i++;continue}x.fill(d,c)?e++:i++}catch(n){h.error("Failed to process individual form field:",n),r++}}catch(p){h.error("Critical failure in autofill execution loop",p),r=1}const s=Math.round(performance.now()-a);return h.info(`Autofill finished: ${o} matched, ${e} filled, ${i} skipped, ${r} failed in ${s}ms.`),{matched:o,filled:e,skipped:i,failed:r,timeMs:s}}},N={extractTextFromPdfBuffer:t=>{const a=new Uint8Array(t);let e="";for(let i=0;i<a.length;i++){const r=a[i];r>=32&&r<=126||r===10||r===13?e+=String.fromCharCode(r):e+=" "}return e},parsePdfProfile:t=>{const a={},e=t.match(/PASSPORT\s*NO[.:\s]+([A-Z0-9]{6,12})/i)||t.match(/Passport\s*Number[.:\s]+([A-Z0-9]{6,12})/i)||t.match(/([A-Z][0-9]{7,8})/);e&&(a.passportNumber=e[1]);const i=t.match(/SURNAME[.:\s]+([A-Z\s]+)/i)||t.match(/Surname[.:\s]+([A-Z\s]+)/i)||t.match(/Last\s*Name[.:\s]+([A-Z\s]+)/i);i&&(a.surname=i[1].trim());const r=t.match(/GIVEN\s*NAME[.:\s]+([A-Z\s]+)/i)||t.match(/Given\s*Name[.:\s]+([A-Z\s]+)/i)||t.match(/First\s*Name[.:\s]+([A-Z\s]+)/i);r&&(a.givenName=r[1].trim());const o=t.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);o&&(a.email=o[1]);const s=t.match(/(?:PHONE|MOBILE|TEL)[.:\s]+([+0-9\s-]{7,15})/i);return s&&(a.phone=s[1].trim()),a}};console.log("[VisaKit] Content script loaded."),chrome.runtime.onMessage.addListener((t,a,e)=>{if(t.action==="AUTOFILL")return P.runAutofill(t.profile).then(i=>{e(i)}).catch(i=>{console.error("[VisaKit] Autofill engine execution failure:",i),e({filled:0,skipped:0,failed:1,timeMs:0})}),!0}),window.location.hostname.includes("indianvisa-bangladesh.nic.in")&&(document.getElementById("visakit-panel-root")||B());function B(){const t=document.createElement("div");t.id="visakit-panel-root",t.style.position="fixed",t.style.zIndex="999999",t.style.top="20px",t.style.right="20px",t.style.width="360px",t.style.fontFamily="Inter, system-ui, -apple-system, sans-serif",t.style.boxSizing="border-box";const a=document.createElement("style");a.textContent=`
    #visakit-panel-root *, #visakit-panel-root *::before, #visakit-panel-root *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    .visakit-card {
      background: rgba(15, 23, 42, 0.95);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2);
      color: #f8fafc;
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
      backdrop-filter: blur(8px);
    }
    .visakit-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: move;
      border-b: 1px solid rgba(255, 255, 255, 0.05);
      padding-bottom: 8px;
    }
    .visakit-logo {
      font-weight: 800;
      font-size: 13px;
      color: #3b82f6;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .visakit-title {
      font-weight: 700;
      font-size: 14px;
      color: #f8fafc;
    }
    .visakit-controls {
      display: flex;
      gap: 6px;
    }
    .visakit-btn-control {
      background: none;
      border: none;
      color: #64748b;
      cursor: pointer;
      font-size: 14px;
      line-height: 1;
      padding: 2px 6px;
      border-radius: 4px;
      transition: all 0.15s;
    }
    .visakit-btn-control:hover {
      background: rgba(255, 255, 255, 0.05);
      color: #f8fafc;
    }
    .visakit-body {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .visakit-label {
      font-size: 10px;
      font-weight: 700;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 4px;
      display: block;
    }
    .visakit-select {
      width: 100%;
      background: #090d16;
      border: 1px solid #1e293b;
      border-radius: 8px;
      color: #e2e8f0;
      padding: 8px 12px;
      font-size: 12px;
      outline: none;
      cursor: pointer;
    }
    .visakit-btn-primary {
      width: 100%;
      background: #2563eb;
      color: #ffffff;
      border: none;
      border-radius: 8px;
      padding: 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.15s;
    }
    .visakit-btn-primary:hover {
      background: #1d4ed8;
    }
    .visakit-input-file {
      font-size: 11px;
      color: #94a3b8;
      margin-top: 4px;
      width: 100%;
    }
    .visakit-toast {
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      margin-top: 6px;
    }
    .visakit-toast-success {
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.2);
      color: #34d399;
    }
    .visakit-toast-error {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.2);
      color: #f87171;
    }
  `,document.head.appendChild(a),t.innerHTML=`
    <div class="visakit-card" id="visakit-panel-card">
      <div class="visakit-header" id="visakit-panel-drag-header">
        <span class="visakit-logo">VisaKit</span>
        <span class="visakit-title">Floating Panel</span>
        <div class="visakit-controls">
          <button class="visakit-btn-control" id="visakit-btn-min">_</button>
          <button class="visakit-btn-control" id="visakit-btn-close">×</button>
        </div>
      </div>
      <div class="visakit-body" id="visakit-panel-body-content">
        <div>
          <label class="visakit-label">Profile Selector</label>
          <select class="visakit-select" id="visakit-profile-selector"></select>
        </div>
        <button class="visakit-btn-primary" id="visakit-btn-trigger-autofill">Quick Autofill</button>
        <div>
          <label class="visakit-label">Import from PDF</label>
          <input type="file" class="visakit-input-file" id="visakit-panel-pdf-upload" accept=".pdf" />
        </div>
        <div id="visakit-panel-toasts"></div>
      </div>
    </div>
  `,document.body.appendChild(t),chrome.storage.local.get(["visakit_panel_top","visakit_panel_right"],l=>{l.visakit_panel_top&&(t.style.top=l.visakit_panel_top),l.visakit_panel_right&&(t.style.right=l.visakit_panel_right)});let e=!1,i=0,r=0;const o=document.getElementById("visakit-panel-drag-header");o==null||o.addEventListener("mousedown",l=>{e=!0,i=l.clientX-t.getBoundingClientRect().left,r=l.clientY-t.getBoundingClientRect().top,l.preventDefault()}),document.addEventListener("mousemove",l=>{if(!e)return;const m=l.clientX-i,u=l.clientY-r;t.style.left=`${m}px`,t.style.top=`${u}px`,t.style.right="auto"}),document.addEventListener("mouseup",()=>{e&&(e=!1,chrome.storage.local.set({visakit_panel_top:t.style.top,visakit_panel_right:t.style.right,visakit_panel_left:t.style.left}))});const s=document.getElementById("visakit-btn-min"),p=document.getElementById("visakit-panel-body-content");s==null||s.addEventListener("click",()=>{if(p){const l=p.style.display==="none";p.style.display=l?"flex":"none",s.textContent=l?"_":"+"}});const d=document.getElementById("visakit-btn-close");d==null||d.addEventListener("click",()=>{t.remove()});const n=document.getElementById("visakit-profile-selector");chrome.storage.local.get("visakit_profiles",l=>{const m=l.visakit_profiles;if(m){let u=[];try{typeof m=="string"?u=JSON.parse(m):Array.isArray(m)&&(u=m)}catch{u=[]}u.forEach(v=>{const g=document.createElement("option");g.value=v.id,g.textContent=`${v.surname}, ${v.givenName} (${v.passportNumber})`,v.isDefault&&(g.selected=!0),n==null||n.appendChild(g)})}});const c=document.getElementById("visakit-btn-trigger-autofill");c==null||c.addEventListener("click",async()=>{c.textContent="Filling fields...";const l=n==null?void 0:n.value;chrome.storage.local.get("visakit_profiles",async m=>{const u=m.visakit_profiles;let v=[];if(u)if(Array.isArray(u))v=u;else try{v=JSON.parse(u)}catch{v=[]}const g=v.find(b=>b.id===l);if(!g){y("Active profile not found.","error"),c.textContent="Quick Autofill";return}try{const b=await P.runAutofill(g);y(`Filled ${b.filled} fields, skipped ${b.skipped}.`,"success")}catch(b){y(b instanceof Error?b.message:"Autofill failed.","error")}finally{c.textContent="Quick Autofill"}})});const f=document.getElementById("visakit-panel-pdf-upload");f==null||f.addEventListener("change",()=>{var u;const l=(u=f.files)==null?void 0:u[0];if(!l)return;const m=new FileReader;m.onload=async v=>{var g;try{const b=(g=v.target)==null?void 0:g.result,U=N.extractTextFromPdfBuffer(b),S=N.parsePdfProfile(U);S.passportNumber?y(`Extracted Passport No: ${S.passportNumber}`,"success"):y("Failed to find passport details in PDF.","error")}catch{y("PDF parsing failed.","error")}},m.readAsArrayBuffer(l)})}function y(t,a){const e=document.getElementById("visakit-panel-toasts");e&&(e.innerHTML=`<div class="visakit-toast visakit-toast-${a}">${t}</div>`,setTimeout(()=>{e.innerHTML=""},4e3))}})();
